package principal;

public class Lanceur {
	
	public static void main(String[] args0) {
		Chien medor = new Chien();
		Pigeon olaf = new Pigeon();
		
		System.out.println("medor.communiquer() : ");
		medor.communiquer();
		System.out.println("olaf.communiquer() : ");
		olaf.communiquer();
		
		System.out.println("medor.seNourrir(fromage) : ");
		medor.seNourrir("fromage");
		System.out.println("medor.seNourrir(croquettes) : ");
		medor.seNourrir("croquettes");
		
		System.out.println("medor.compareTo(olaf) : ");
		System.out.println(medor.compareTo(olaf));
		System.out.println("medor.compareTo(medor) : ");
		System.out.println(medor.compareTo(medor));
		
	}
}
